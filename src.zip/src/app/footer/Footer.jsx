

const Footer = () => {
  return (
    <div className="footer-container">


<h1>bu footer</h1>




    </div>
  )
}

export default Footer