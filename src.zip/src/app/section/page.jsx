import './section.css'
import Image from 'next/image'

const Section = () => {
    return (
 <div>
    <h1>Salom bu section</h1>
 </div>
    )
}

export default Section